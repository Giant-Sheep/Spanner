//
//  TestSpanner.h
//  Spanner
//
//  Created by Matias Piispanen on 4/8/11.
//  Copyright 2011 TU/e. All rights reserved.
//
#pragma once

#include "Spanner.h"

using namespace std;

class TestSpanner : public Spanner {
    
public:
    TestSpanner(vector<Point *> points, double t);
	vector<vector<double> > getAdjacency();
};